# Project State

## Estado actual

-   Versión:
-   Última fecha:
-   Rama:
-   Objetivo activo:
-   Bloqueos:
-   Próximo hito:
