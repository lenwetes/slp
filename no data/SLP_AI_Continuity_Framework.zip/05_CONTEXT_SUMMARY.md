# Context Summary

Máximo 300 palabras. Debe permitir que un nuevo agente continúe el
proyecto leyendo solo este archivo y PROJECT_STATE.
