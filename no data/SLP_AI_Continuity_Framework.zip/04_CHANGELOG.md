# Changelog

Registrar cambios relevantes por sesión.
